const DATA_URL = "/data/products.json";

const productList = document.querySelector("#productList");
const featureList = document.querySelector("#featureList");
const heroEyebrow = document.querySelector("#heroEyebrow");
const heroTitle = document.querySelector("#heroTitle");
const heroDescription = document.querySelector("#heroDescription");
const heroImage = document.querySelector("#heroImage");
const heroButton = document.querySelector("#heroButton");
const footerLogo = document.querySelector("#footerLogo");
const footerDescription = document.querySelector("#footerDescription");
const footerCopyright = document.querySelector("#footerCopyright");
const cartCount = document.querySelector("#cartCount");

let cartTotal = 0;

async function loadData() {
  try {
    const response = await fetch(DATA_URL);

    if (!response.ok) {
      throw new Error(`JSON 載入失敗：${response.status}`);
    }

    const data = await response.json();

    renderSite(data.site);
    renderFeatures(data.features);
    renderProducts(data.products);
  } catch (error) {
    console.error(error);

    if (productList) {
      productList.innerHTML = `
        <p class="productSection__error">
          無法載入商品資料，請確認 /data/products.json 是否存在。
        </p>
      `;
    }
  }
}

function renderSite(site) {
  if (!site) return;

  document.title = site.name || document.title;

  if (site.hero) {
    heroEyebrow.textContent = site.hero.eyebrow || "";
    heroTitle.textContent = site.hero.title || "";
    heroDescription.textContent = site.hero.description || "";
    heroButton.textContent = site.hero.buttonText || "立即選購";

    if (site.hero.image) {
      heroImage.src = site.hero.image;
    }

    if (site.hero.imageAlt) {
      heroImage.alt = site.hero.imageAlt;
    }
  }

  footerLogo.textContent = site.name || "";
  footerDescription.textContent = site.footerDescription || "";
  footerCopyright.textContent = site.copyright || "";
}

function renderFeatures(features = []) {
  featureList.innerHTML = features.map((feature) => `
    <article class="featureCard">
      <div class="featureCard__icon" aria-hidden="true">${feature.icon || ""}</div>
      <h3 class="featureCard__title">${feature.title || ""}</h3>
      <p class="featureCard__description">${feature.description || ""}</p>
    </article>
  `).join("");
}

function renderProducts(products = []) {
  productList.innerHTML = products.map((product) => `
    <article class="productCard">
      <div class="productCard__image">
        ${product.tag ? `<span class="productCard__tag">${product.tag}</span>` : ""}
        <img
          src="${product.image}"
          alt="${product.imageAlt || product.name}"
          loading="lazy"
        >
      </div>

      <div class="productCard__body">
        <h3 class="productCard__name">${product.name}</h3>

        <div class="productCard__price">
          <span class="productCard__currentPrice">
            $${Number(product.price).toLocaleString()}
          </span>

          ${
            product.originalPrice
              ? `<span class="productCard__originalPrice">
                  $${Number(product.originalPrice).toLocaleString()}
                </span>`
              : ""
          }
        </div>

        <button
          class="productCard__button"
          type="button"
          data-product-id="${product.id}"
        >
          加入購物車
        </button>
      </div>
    </article>
  `).join("");

  productList.querySelectorAll(".productCard__button").forEach((button) => {
    button.addEventListener("click", () => {
      cartTotal += 1;
      cartCount.textContent = cartTotal;
    });
  });
}

loadData();
